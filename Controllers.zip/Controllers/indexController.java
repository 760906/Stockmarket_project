package com.example.StockMarketCharting.Controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class indexController {
	@RequestMapping(value="/index")
	public String getIndexPage()
	{
		
		return "LoginPage";
	}
	@RequestMapping(value="/RegisterPage")
	public String getRegisterPage()
	{
		
		return "SignUpPage";
	}
	
	@RequestMapping(value="/Forgotpassword")
	public String forgotPassword()
	{
		
		return "ForgotPassword";
	}
}
