package com.example.StockMarketCharting.Controllers;

import java.util.Optional;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.StockMarketCharting.Models.User;
import com.example.StockMarketCharting.Services.UserService;

@Controller
public class RegisterController {

	
	@Autowired
	UserService userservice;
	
	public static String send(String from,String password,String to,String sub,String msg){  
	    //Get properties object    
	    Properties props = new Properties();    
	      
	    props.put("mail.smtp.host", "smtp.gmail.com");    
	    props.put("mail.smtp.socketFactory.port", "465");    
	    props.put("mail.smtp.socketFactory.class",    
	              "javax.net.ssl.SSLSocketFactory");    
	    props.put("mail.smtp.auth", "true");    
	    props.put("mail.smtp.port", "465"); 
	    Session session = Session.getDefaultInstance(props,   
	     new javax.mail.Authenticator() {    
	     protected PasswordAuthentication getPasswordAuthentication() {    
	     return new PasswordAuthentication(from,password);  
	     }    
	    });    
	    //compose message    
	    try {    
	     MimeMessage message = new MimeMessage(session);    
	     message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));    
	     message.setSubject(sub);    
	     message.setText(msg);    
	     //send message  
	     Transport.send(message);    
	     System.out.println("message sent successfully"); 
	     return "Success";
	    } catch (MessagingException e) {
	    	System.out.println("Error While Sending and \n Error is :"+e);
	    	return "Failure";
	    
	    } 
	}
	
	@RequestMapping(value="/signupuser",method = RequestMethod.POST)
	public ModelAndView signupUserDB(@RequestParam("Username")String username, @RequestParam("Password")String password,@RequestParam("E_Mail")String mail,@RequestParam("Contact")String contact)
	{
		int contact2 = Integer.parseInt(contact);	
		 Optional<User> userdata =  userservice.findUser(username,mail,contact2);
		 ModelAndView mv = new ModelAndView();
		 if(userdata.isPresent())
		 {
			 if(userdata.get().getUsername().contentEquals(username))
			 {
			 System.out.println("Username exists ");
			 }
			 if(userdata.get().getEmail().contentEquals(mail))
			 {
			 System.out.println("mail exists ");
			 }
			 if(userdata.get().getMobilenumber() == contact2)
			 {
			 System.out.println("Contact number exists ");
			 }
			 mv.setViewName("SignUpPage");
		 }
		 else
		 {
			
			 int randomPin   =(int)(Math.random()*9000)+1000;
				String otp  =String.valueOf(randomPin);
				System.out.println("OTP : "+otp);
			           
			
			         // String message = " Verification Code is : "+otp+"\n Happy Exploring!!"; 
				    
			         // String Sent = RegisterController.send("shashidharreddy082@gmail.com","Bharath@123",mail,"Verification code for Stock Exchange",message);
				     String Sent = "Success";
			      
			       
			         if(Sent.contentEquals("Success"))
						{
			        	 
			        	int contact1 = Integer.parseInt(contact);	
			 		    User userObj = new User(username,password,"UU",mail,contact1,otp);
			 		    userservice.save(userObj);
			 		    mv.setViewName("ConfirmationPage");
			 		   mv.addObject("username",userObj.getUsername());
						 mv.addObject("mail",userObj.getEmail());
						 mv.addObject("UserId",userObj.getId());
						}
			         
			         else if(Sent.contentEquals("Failure"))
			         {
			        	 System.out.println("Error While Sending message Or Incorrect mail");
			        	 mv.setViewName("SignUpPage");
			         }
			 
		 }
	             return mv;
	}
	
	@RequestMapping(value="/ConfirmMail",method = RequestMethod.POST)
	public ModelAndView ConfirmMail(@RequestParam("E_Mail")String E_Mail)
	{
		
		 ModelAndView mv = new ModelAndView();
		 User userdata = new User();
		 userdata= userservice.findByEmail(E_Mail);
		// System.out.println("Before Finding Out Side"+userdata.getEmail());
		 if(userdata == null)	 
		 {
			 System.out.println("Email is incorrect");
			 mv.setViewName("ForgotPassword");
		 }
		 else if(userdata.getEmail().contentEquals(E_Mail))
		 {
			   
				 
				    int randomPin   =(int)(Math.random()*9000)+1000;
					String otp  =String.valueOf(randomPin);
					System.out.println("OTP : "+otp);
					
	
					
					 // String message = " Verification Code is : "+otp+"\n Happy Exploring!!"; 
				    
			         // String Sent = RegisterController.send("shashidharreddy082@gmail.com","Bharath@123",mail,"Verification code for Stock Exchange",message);
				     String Sent = "Success";
					if(Sent.contentEquals("Success"))
					{
						System.out.println("OTP : Success");
						//User.setConfirmed(otp);
						//System.out.println("Before Finding"+userdata.getId());
						Optional<User> userdataObj = userservice.findById(userdata.getId());
						System.out.println(userdataObj.toString());
						if (userdataObj.isPresent()) {
							User UserdataObj1 = userdataObj.get();
							UserdataObj1.setConfirmed(otp);
							userservice.save(UserdataObj1);
							 System.out.println("Please Check the mail");
						     mv.setViewName("ConfirmationPage1");
					         mv.addObject("username",userdata.getUsername());
							 mv.addObject("mail",userdata.getEmail());
							 mv.addObject("UserId",userdata.getId());
						}
						else {
							mv.setViewName("ForgotPassword");
							
						}
						
						
					   
					}
					else  if(Sent.contentEquals("Failure"))
					{
						System.out.println("Error While Sending message ");
						
						 mv.setViewName("ForgotPassword");
					}
					
		 }
		 
		 return mv;
	}
	
	@RequestMapping(value="/verifycode/{id}",method = RequestMethod.POST)
	public ModelAndView verifyUserCode(@PathVariable("id") int id,@RequestParam("code")String code, @RequestParam("username")String username,@RequestParam("mail")String mail)
	{
		
		 Optional<User> userdata =  userservice.findById(id,code);
		 System.out.println("user data  :"+userdata.toString());
		 ModelAndView mv = new ModelAndView();
		 if(userdata.isPresent())
		 {
			 
			 System.out.println("Verifying Code");
			    User UserdataObj1 = userdata.get();
				UserdataObj1.setUsertype("CU");
				userservice.save(UserdataObj1);
				System.out.println("Verified Successfully");
			    mv.setViewName("LoginPage");
			
		 }
		 else
		 {
			 System.out.println("Verification Code is wrong Please enter correct Code");
			 mv.setViewName("ConfirmationPage");
	         mv.addObject("username",username);
			 mv.addObject("mail",mail);
			 mv.addObject("UserId",id);
		 }
		
		 return mv;
	}
	
	
	@RequestMapping(value="/confirmusercode/{id}",method = RequestMethod.POST)
	public ModelAndView confirmUserCode(@PathVariable("id") int id,@RequestParam("code")String code, @RequestParam("password")String password,@RequestParam("username")String username,@RequestParam("mail")String mail)
	{
		
		 Optional<User> userdata =  userservice.findById(id,code);
		 System.out.println("user data  :"+userdata.toString());
		 ModelAndView mv = new ModelAndView();
		 if(userdata.isPresent())
		 {
			 
			 System.out.println("Changing password in database");
			    User UserdataObj1 = userdata.get();
				UserdataObj1.setPassword(password);
				userservice.save(UserdataObj1);
				System.out.println("password Changed Successfully");
			    mv.setViewName("LoginPage");
			
		 }
		 else
		 {
			 System.out.println("Verification Code is wrong Please enter correct Code");
			 mv.setViewName("ConfirmationPage1");
	         mv.addObject("username",username);
			 mv.addObject("mail",mail);
			 mv.addObject("UserId",id);
		 }
		
		 return mv;
	}
	
	
}
